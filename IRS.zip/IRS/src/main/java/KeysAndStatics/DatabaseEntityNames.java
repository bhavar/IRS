/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KeysAndStatics;

/**
 *
 * @author bhawar
 */
public class DatabaseEntityNames 
{
    
    private static String dataBaseName = "products";
    private static String collection_name = "productCollection";
    private static String resource_bucket = "productResourceCollection";
    private static String image_bucket = "productImageCollection";
    private static String activeUserDatabase = "activeUsers";
    private static String activeUserDatabaseCollection = "activeUsersCollection";
    private static String registeredUserDatabase = "registeredUsers";
    private static String registeredUserDatabaseCollection="registeredUserCollection";
    
    public static String getActiveUserDatabase()
    {
        return activeUserDatabase;
    }
    
    public static String getActiveUserDatabaseCollection()
    {
        return activeUserDatabaseCollection;
    }
   
    public static String getProductDatabaseName()
    {
        return dataBaseName;
    }
    
    public static String getProductCollectionName()
    {
        return collection_name;
    }
    
    public static String getResourceBucketName()
    {
        return resource_bucket;
    }
    
    public static String getImageBucketName()
    {
        return image_bucket;
    }

    /**
     * @return the registeredUserDatabase
     */
    public static String getRegisteredUserDatabase() {
        return registeredUserDatabase;
    }

    /**
     * @return the registeredUserDatabaseCollection
     */
    public static String getRegisteredUserDatabaseCollection() {
        return registeredUserDatabaseCollection;
    }
    
}
