/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Authenticator;

import DatabaseHandler.DatabaseConnectionManager;
import KeysAndStatics.DatabaseEntityNames;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import com.mongodb.client.result.DeleteResult;
import org.bson.Document;
import org.bson.types.ObjectId;

/**
 *
 * @author bhawar
 */
public class AuthenticateUser 
{
    
    public boolean isSecureKey(String key)
    {
        DatabaseConnectionManager dbCon = new DatabaseConnectionManager();
        try
        {
            MongoDatabase mongoDatabase = dbCon.setUpDatabaseConnection(DatabaseEntityNames.getActiveUserDatabase());
            MongoCollection activeUserCollection = mongoDatabase.getCollection(DatabaseEntityNames.getActiveUserDatabaseCollection());
            Document activeUserDocument = (Document) activeUserCollection.find(eq("_id",new ObjectId(key))).first();
            if(activeUserDocument!=null)
            {
                return true;
            }
        }
        catch(Exception exception){}
        finally
        {
            dbCon.terminateDatabaseConnection();
        }
        return false;
    }
    
    public String login(String userName,String password)
    {
        DatabaseConnectionManager dbCon = new DatabaseConnectionManager();
        try
        {
            MongoDatabase mongoDatabase = dbCon.setUpDatabaseConnection(DatabaseEntityNames.getRegisteredUserDatabase());
            MongoCollection mongoCollection = mongoDatabase.getCollection(DatabaseEntityNames.getRegisteredUserDatabaseCollection());
            Document registeredUser = (Document) mongoCollection.find(and(eq("userName",userName),eq("password",password))).first();
            if(registeredUser!=null)
            {
                //Make an entry in the active User Collection
                //Enter the _id of the registered User
                //Create a request_key or use the _id of the activeUserCollection
                return this.createRequestKey(registeredUser.get("_id").toString());               
            }
        }
        catch(Exception exception)
        {
            System.out.println(exception.getMessage());
        }
        finally
        {
            dbCon.terminateDatabaseConnection();
        }
        return "error";
    }
    
    public String createRequestKey(String userId)
    {
        DatabaseConnectionManager dbCon = new DatabaseConnectionManager();
        try
        {
            System.out.println("user id "+userId);
            MongoDatabase mongoDatabase = dbCon.setUpDatabaseConnection(DatabaseEntityNames.getActiveUserDatabase());
            MongoCollection mongoCollection = mongoDatabase.getCollection(DatabaseEntityNames.getActiveUserDatabaseCollection());
            
            //Delete the entry id any to invalidate previous key
            mongoCollection.deleteOne(eq("userId",userId));
            
            Document document = new Document();
            document.append("userId",userId);
            mongoCollection.insertOne(document);
            
            document = (Document)mongoCollection.find(eq("userId",userId)).first();
            //return the newly created records id as request_key;
            return document.get("_id").toString();
            
        }
        catch(Exception exception)
        {
            System.out.println(exception.getMessage());
        }
        finally
        {
            dbCon.terminateDatabaseConnection();
        }
        return null;
    }
    
    public boolean logout(String request_key)
    {
        DatabaseConnectionManager dbCon = new DatabaseConnectionManager();
        try
        {
            MongoDatabase mongoDatabase = dbCon.setUpDatabaseConnection(DatabaseEntityNames.getActiveUserDatabase());
            MongoCollection mongoCollection = mongoDatabase.getCollection(DatabaseEntityNames.getActiveUserDatabaseCollection());
            
            //Delete the entry id any to invalidate previous key
            DeleteResult deleteResult = mongoCollection.deleteOne(eq("_id",new ObjectId(request_key)));
            return deleteResult.wasAcknowledged();
        }
        catch(Exception exception)
        {
            System.out.println(exception.getMessage());
        }
        finally
        {
            dbCon.terminateDatabaseConnection();
        }
        return false;
    }
}
