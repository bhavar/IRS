/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package APIBrokers;

import DatabaseHandler.DatabaseConnectionManager;
import KeysAndStatics.DatabaseEntityNames;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import static com.mongodb.client.model.Filters.eq;
import java.io.File;
import java.io.FileOutputStream;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author bhawar
 */
public class ProductImageResourceBroker 
{
    
    public File getImageByFileName(String product_image_file_name) {
        DatabaseConnectionManager dbcon = new DatabaseConnectionManager();
        try {
            System.out.println("Executing Core");
            MongoDatabase mongoDatabase = dbcon.setUpDatabaseConnection(DatabaseEntityNames.getProductDatabaseName());
            GridFSBucket gridFSBucket = GridFSBuckets.create(mongoDatabase, DatabaseEntityNames.getImageBucketName());
            
            //Search the file in DB
            MongoCollection mongoCollection = mongoDatabase.getCollection(DatabaseEntityNames.getImageBucketName()+".files");
            Document document = (Document) mongoCollection.find(eq("filename",product_image_file_name)).first();
            
            //Fetch $oid from JSON Document
            JSONParser parser = new JSONParser();
            JSONObject jsonObject=(JSONObject) parser.parse(document.toJson());
            JSONObject oid = (JSONObject) jsonObject.get("_id");
           
            File file_obj = new File("/tmp/temp_hold.bin");

            String image_file_id=oid.get("$oid").toString();
            System.out.println(document.toJson());
            FileOutputStream streamToDownloadTo = new FileOutputStream(file_obj);
            gridFSBucket.downloadToStream(new ObjectId(image_file_id), streamToDownloadTo);
            streamToDownloadTo.flush();
            streamToDownloadTo.close();
            return file_obj;

        } 
        catch (Exception exception) 
        {
            System.out.println(exception.getMessage());
        } 
        finally 
        {
            dbcon.terminateDatabaseConnection();
        }
        return null;
    }
}
