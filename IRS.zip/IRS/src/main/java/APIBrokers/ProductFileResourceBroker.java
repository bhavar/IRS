/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package APIBrokers;

import DatabaseHandler.DatabaseConnectionManager;
import KeysAndStatics.DatabaseEntityNames;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import static com.mongodb.client.model.Filters.eq;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.IOUtils;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author bhawar
 */
public class ProductFileResourceBroker
{
    public File getFileByFileId(String product_resource_fileid ,String metadata) {
        
        System.out.println("Inside Function");
        //metadata to check if the file request is for siemens or haas and also check the array params
        
        DatabaseConnectionManager dbcon = new DatabaseConnectionManager();
        try 
        {
            
            MongoDatabase mongoDatabase = dbcon.setUpDatabaseConnection(DatabaseEntityNames.getProductDatabaseName());
            GridFSBucket gridFSBucket = GridFSBuckets.create(mongoDatabase, DatabaseEntityNames.getResourceBucketName());
            
            System.out.println("Attempting to search");
            //Search the file in DB
            MongoCollection mongoCollection = mongoDatabase.getCollection(DatabaseEntityNames.getResourceBucketName()+".files");
            Document document = (Document) mongoCollection.find(eq("_id",new ObjectId(product_resource_fileid))).first();
            System.out.println("Found : "+document.get("_id").toString());
            
            File file_obj = new File("/tmp/"+document.getString("filename"));

            FileOutputStream streamToDownloadTo = new FileOutputStream(file_obj);
            gridFSBucket.downloadToStream(new ObjectId(product_resource_fileid), streamToDownloadTo);
            streamToDownloadTo.flush();
            streamToDownloadTo.close();
            
            
            //Parse metadata for different file
            if(!document.isEmpty())
            {
                String filename = document.getString("filename");
                if(filename.contains("nc"))
                {
                    if(!metadata.contains("{"))
                    {
                        System.out.println("Generating Plain File");
                        JSONObject jsonObject = new JSONObject();
                        JSONArray jsonArray = new JSONArray();
                        jsonArray.add("0");
                        jsonObject.put("array",jsonArray);
                        jsonObject.put("shift","x");
                        return this.makeFileMultiple(file_obj, jsonObject, filename);
                    }
                    else
                    {
                        JSONParser jsonParser = new JSONParser();
                        JSONObject jsonObject = (JSONObject) jsonParser.parse(metadata);
                        return this.makeFileMultiple(file_obj, jsonObject, filename);
                    }
                }
                
                else
                {
                    return file_obj;
                }
            }
            
            return null;
            
           
            
        } 
        catch (Exception exception) 
        {
            System.out.println(exception.getMessage());
            return null;
        } 
        finally 
        {
            dbcon.terminateDatabaseConnection();
        }
    }
    
    public File makeFileMultiple(File file_obj , JSONObject jsonObject,String fileName) throws IOException
    {
        
        System.out.println("Making Multiple");
        ArrayList headers = new ArrayList(); 
        headers.add("(MAIN PROGRAM) \n G90 G54 \n");
        
        JSONArray jsonArray = (JSONArray) jsonObject.get("array");
        String shift = jsonObject.get("shift").toString();
        
        for(int i=0;i<jsonArray.size();i++)
        {
            headers.add("G92 "+shift+"="+jsonArray.get(i)+"\n");
            headers.add("(CALL SUBPROGRAM FOR "+i+"/"+jsonArray.size()+") \n");
            headers.add("M98 P1996 \n");
            headers.add("(---END CALL---) \n");
        }
        
        headers.add("\n\n(SUB PROGRAM START)");
        headers.add("\n%O1996 \n");
        
        File file = new File("/tmp/"+"edit"+fileName);
        BufferedWriter buffered = new BufferedWriter(new FileWriter(file));
        for(int i = 0 ;i<headers.size();i++)
        {
            buffered.write((String) headers.get(i).toString());
        }
        
        BufferedReader br = new BufferedReader(new FileReader(file_obj));
        String line;
            while ((line = br.readLine()) != null)
            {
                buffered.append(line);
            }
            
        buffered.close();
        br.close();
        
        String final_md5 = DigestUtils.md5Hex(IOUtils.toByteArray(new FileInputStream(file)));
        BufferedWriter re_buffered = new BufferedWriter(new FileWriter(file,true));
        re_buffered.append("\n(Digest Hash : "+final_md5+")");
        re_buffered.flush();
        re_buffered.close();
        return file;
    }
    
    public File deployDWG(File file_obj,String filename)
    {
        return null;
    }
    
}
