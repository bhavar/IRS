/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package APIBrokers;

import DatabaseHandler.DatabaseConnectionManager;
import KeysAndStatics.DatabaseEntityNames;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.eq;
import com.mongodb.client.model.Projections;
import javax.activation.MimetypesFileTypeMap;
import javax.ws.rs.core.Response;
import org.bson.Document;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author bhawar
 */
public class ProductInformationBroker {

    public Response getProductDetailByName(String product_name) {
        //Find the product by using name
        //Incorporate all the product links and resource links with the product
        DatabaseConnectionManager dbcon = new DatabaseConnectionManager();
        try {
            MongoDatabase mongoDatabase = dbcon.setUpDatabaseConnection(DatabaseEntityNames.getProductDatabaseName());

            //Search the file in DB
            MongoCollection mongoCollection = mongoDatabase.getCollection(DatabaseEntityNames.getProductCollectionName());
            Document document = (Document) mongoCollection.find(eq("PRODUCT_NAME", product_name)).first();
            document.append("IMAGES",this.getImageLinksByProductName(product_name, mongoDatabase));
            document.append("RESOURCES",this.getFileLinksByProductName(product_name, mongoDatabase));
            document.append("image_link", "/product/images/{image_filename}");
            document.append("resource_link", "/product/resource/{file_id,meta_data}");
            
            
            System.out.println(document.toJson().toString());

            if (document != null) {
                String mt = new MimetypesFileTypeMap().getContentType("application/json");
                return Response.ok().entity(document.toJson()).build();
            } else {
                return Response.noContent().entity("No such Data Available").build();
            }

        } catch (Exception exception) {
            System.out.println(exception.getMessage());
            return Response.serverError().build();
        } finally {
            dbcon.terminateDatabaseConnection();
        }
    }

    public JSONArray getImageLinksByProductName(String product_name, MongoDatabase mongoDatabase) {

        JSONArray jsonResponseArray = new JSONArray();
        try {
            MongoCollection fileBucketCollection = mongoDatabase.getCollection(DatabaseEntityNames.getImageBucketName() + ".files");

            MongoCursor<Document> mongoCursor = fileBucketCollection.find(eq("metadata.product_name", product_name)).
                    projection(Projections.include("uploadDate","filename","md5", "metadata.product_name", "_id")).iterator();
            
            JSONParser jsonParser = new JSONParser();
            while(mongoCursor.hasNext())
            {
                JSONObject jsonObject = (JSONObject) jsonParser.parse(mongoCursor.next().toJson().toString());
                jsonResponseArray.add(jsonObject);
            }
            return jsonResponseArray;

        } catch (Exception exception) {
            System.out.println(exception.getMessage());
            jsonResponseArray.add("No Data");
            return jsonResponseArray;
        } finally {

        }
    }

    public JSONArray getFileLinksByProductName(String product_name, MongoDatabase mongoDatabase) {

        JSONArray documentCollection = new JSONArray();
        try {
            MongoCollection fileBucketCollection = mongoDatabase.getCollection(DatabaseEntityNames.getResourceBucketName() + ".files");

            MongoCursor<Document> mongoCursor = fileBucketCollection.find(eq("metadata.product_name", product_name)).
                    projection(Projections.include("uploadDate","filename", "md5", "metadata.product_name", "metadata.version_name","metadata.product_size")).iterator();

            JSONParser jsonParser = new JSONParser();
            while(mongoCursor.hasNext())
            {
                JSONObject jsonObject = (JSONObject) jsonParser.parse(mongoCursor.next().toJson().toString());
                documentCollection.add(jsonObject);
            }
            return documentCollection;

        } catch (Exception exception) {
            exception.getMessage();
            documentCollection.add("No Resource Available");
            return documentCollection;
        } finally {

        }
    }

    public JSONObject getAllProductNames() {
        DatabaseConnectionManager dbcon = new DatabaseConnectionManager();
        try {
            MongoDatabase mongoDatabase = dbcon.setUpDatabaseConnection(DatabaseEntityNames.getProductDatabaseName());

            //Search the file in DB
            MongoCollection mongoCollection = mongoDatabase.getCollection(DatabaseEntityNames.getProductCollectionName());
            MongoCursor mongoCursor = mongoCollection.find().projection(Projections.include("PRODUCT_NAME")).iterator();
            
            JSONObject responsePackage = new JSONObject();
            JSONArray namesArray = new JSONArray();
            while (mongoCursor.hasNext())
            {
                Document document = (Document) mongoCursor.next();
                namesArray.add(document.toJson());
                System.out.println(document.toJson());
            }
            
            responsePackage.put("names", namesArray);
            return responsePackage;
        } 
        catch (Exception exception) {
            
            System.out.println(exception);

        } finally {
            dbcon.terminateDatabaseConnection()
           ;
        }
        return null;
    }

}
