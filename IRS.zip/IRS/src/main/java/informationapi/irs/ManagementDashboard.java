/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package informationapi.irs;

import Authenticator.AuthenticateUser;
import DatabaseHandler.ImageFileCRUDManager;
import DatabaseHandler.ProductCRUDManager;
import DatabaseHandler.ResourceFileCRUDManager;
import Template.FileMetaData;
import java.io.InputStream;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * REST Web Service
 *
 * @author bhawar
 */
@Path("managementDashboard")
public class ManagementDashboard {

    @Context
    private UriInfo context;

    public ManagementDashboard() {
    }

    @Path("demo")
    @GET
    public void getTime() 
    {
        System.out.println("Service Running ");
    }

    @Path("files/resources/product/new/")
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.TEXT_PLAIN)
    public Response addProductFiles(@FormDataParam("file") InputStream fis,
            @FormDataParam("file") FormDataContentDisposition fdcd ,@FormDataParam("request_key") String request_key, @FormDataParam("metadata") String meta_data) 
    {
        //Expects the following keywords and data in the request
        //field : file , The main Resource file
        //field : metadata , The metadata string has PRODUCT_NAME , VERSION_NAME;
        
        try
        {
            AuthenticateUser authenticateUser = new AuthenticateUser();
            if(!authenticateUser.isSecureKey(request_key))
            {
                return Response.status(Response.Status.UNAUTHORIZED).build();
            }
            JSONParser parse = new JSONParser();
            JSONObject json_obj = (JSONObject) parse.parse(meta_data);

            ResourceFileCRUDManager fileCrudManager = new ResourceFileCRUDManager();
            FileMetaData metaData = new FileMetaData();
            metaData.setFILE_NAME(fdcd.getFileName());
            metaData.setPRODUCT_NAME(json_obj.get("PRODUCT_NAME").toString());
            metaData.setVERSION_NAME(json_obj.get("VERSION_NAME").toString());
            metaData.setProductSize("PRODUCT_SIZE");

            System.out.println(metaData.getVERSION_NAME());
            if (fileCrudManager.insertProductResourceFile(fis, metaData)) {
                return Response.ok().entity("File Added").build();
            }
            return Response.status(Response.Status.BAD_REQUEST).build();

            
        }
        catch(ParseException exception)
        {
            return Response.ok().status(Response.Status.BAD_REQUEST).entity(exception.getMessage()).build();
        }
    }

    @Path("files/resources/product/delete/")
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.TEXT_PLAIN)
    public Response deleteProductFiles(@FormDataParam("file_id") String file_id) {
        
        //Expects the following fields
        //field : file_id to remove the file from the collection;
        
        ResourceFileCRUDManager fileCrudManager = new ResourceFileCRUDManager();
        try
        {
        
        JSONParser jsonParser = new JSONParser();
        JSONObject jsonObject = (JSONObject)jsonParser.parse(file_id);
        
        if (fileCrudManager.deleteProductResourceFile(jsonObject)) 
        {
            return Response.ok().entity("File Deleted").build();
        }
        
        else
        {
         
            return Response.ok().status(Response.Status.BAD_REQUEST).build();
            
        }
        }
        catch(ParseException exception)
        {
            return Response.ok().status(Response.Status.BAD_REQUEST).build();
        }
    }
    
    @Path("files/resources/product/update")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_PLAIN)
    public Response updateProductResourceFilesInfo(@FormParam("request_key") String request_key,
                                                    @FormParam("metadata") String metadata)
    {
       //expects metadata
        //exppects metadata : file_id,product_name,product_size,version_name , new_fileName
       try
        {
            System.out.println(metadata +" received as metadata");
            AuthenticateUser authenticateUser = new AuthenticateUser();
            if(!authenticateUser.isSecureKey(request_key))
            {
                return Response.status(Response.Status.UNAUTHORIZED).build();
            }
            
            JSONParser jsonParser  = new JSONParser();
            JSONObject jsonObject = (JSONObject) jsonParser.parse(metadata);
            System.out.println("Successfully parsed JSON");
            ResourceFileCRUDManager resourceFileManager = new ResourceFileCRUDManager();
            if(resourceFileManager.updateProductInformation(jsonObject))
            {
                return Response.status(Response.Status.OK).build();
            }
            else
            {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
            }
            
        }
        catch(Exception exception)
        {
            System.out.println(exception.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @Path("files/images/product/new/")
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.TEXT_PLAIN)
    public Response addProductImageFiles(@FormDataParam("file") InputStream fis,
            @FormDataParam("file") FormDataContentDisposition fdcd ,@FormDataParam("request_key") String request_key,@FormDataParam("metadata") String meta_data) 
    {
        //Expects the following keywords and data in the request
        //field : file , The main Resource file
        //field : metadata , The metadata string has PRODUCT_NAME
        
        try
        {
            AuthenticateUser authenticateUser = new AuthenticateUser();
            if(!authenticateUser.isSecureKey(request_key))
            {
                return Response.status(Response.Status.UNAUTHORIZED).build();
            }
            JSONParser parse = new JSONParser();
            JSONObject json_obj = (JSONObject) parse.parse(meta_data);  

            ImageFileCRUDManager fileCrudManager = new ImageFileCRUDManager();
            FileMetaData metaData = new FileMetaData();
            metaData.setFILE_NAME(fdcd.getFileName());
            metaData.setPRODUCT_NAME(json_obj.get("PRODUCT_NAME").toString());

            System.out.println(metaData.getVERSION_NAME());
            if(fileCrudManager.insertProductImageFile(fis,metaData))
            {
                return Response.ok().entity("File Added").build();
            }
            return Response.status(Response.Status.BAD_REQUEST).build();

        }
        catch(ParseException exception)
        {
            return Response.ok().status(Response.Status.BAD_REQUEST).build();
        }
    }

    @Path("files/images/product/delete/")
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.TEXT_PLAIN)
    public Response deleteProductImageFiles(@FormDataParam("file_id") String file_id) {
        
        //Expects the following fields
        //field : file_id to remove the file from the collection;
        
        ImageFileCRUDManager fileCrudManager = new ImageFileCRUDManager();
        
        try
        {
        
        JSONParser jsonParser = new JSONParser();
        JSONObject jsonObject = (JSONObject)jsonParser.parse(file_id);
        
        if (fileCrudManager.deleteProductImageFile(jsonObject)) {
            return Response.ok().entity("File Deleted").build();
        }
        }
        catch(ParseException exception)
        {
            Response.ok().status(Response.Status.BAD_REQUEST).build();
        }
        
        finally
        {
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).build();
        }

    }
       
    @Path("register/product/new")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response insertProduct(@FormParam("product_static_information") String request_string,@FormParam("request_key") String request_key) throws ParseException {
        
        AuthenticateUser authenticateUser = new AuthenticateUser();
        
        if(authenticateUser.isSecureKey(request_key))
        {

            ProductCRUDManager productManager = new ProductCRUDManager();
            JSONParser parse = new JSONParser();
            JSONObject json_obj = (JSONObject) parse.parse(request_string);
            if (productManager.insertProduct(json_obj)) {
                return Response.ok().status(Response.Status.CREATED).entity("Product Inserted").build();
            }
            return Response.ok().entity(json_obj.toJSONString()).build();
        }
        else
        {
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }
    }
    
    @Path("register/product/delete")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response deleteProduct(@FormParam("product_id") String _id, @FormParam("request_key") String request_key) throws ParseException {
        AuthenticateUser authenticateUser= new AuthenticateUser();
        if(authenticateUser.isSecureKey(request_key))
        {
            ProductCRUDManager productManager = new ProductCRUDManager();
            JSONParser parse = new JSONParser();
            JSONObject json_obj = (JSONObject) parse.parse(_id);
            if (productManager.deleteProduct(json_obj)) {
                return Response.ok().entity("Product Deleted " + _id).build();
            }
            return Response.serverError().build();
        }
        else
        {
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }
    }

    @Path("register/product/update")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response updateProduct(@FormParam("product_static_information") String request_string , @FormParam("request_key") String request_key) {
        try 
        {
            AuthenticateUser authenticateUser = new AuthenticateUser();
            if(!authenticateUser.isSecureKey(request_key))
            {
                return Response.status(Response.Status.UNAUTHORIZED).build();
            }
            ProductCRUDManager productManager = new ProductCRUDManager();
                JSONParser parse = new JSONParser();
                JSONObject json_obj = (JSONObject) parse.parse(request_string);
                
                if(productManager.updateProduct(json_obj))
                {
                    return Response.ok().entity("Product Updated").build();
                }
                else
                {
                    return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
                }
        } 
        catch(ParseException exception)
        {
            System.out.println(exception.getMessage());
            return Response.ok().status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }
}
