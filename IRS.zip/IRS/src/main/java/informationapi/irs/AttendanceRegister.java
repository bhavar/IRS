/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package informationapi.irs;

import Authenticator.AuthenticateUser;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.simple.JSONObject;

/**
 * REST Web Service
 *
 * @author bhawar
 */
@Path("loginManager")
public class AttendanceRegister {

    
    @GET
    @Path("/test")
    public String test()
    {
        return "Working";
    }
    @GET
    @Path("/login")
    @Produces(MediaType.APPLICATION_JSON)
    public Response loginManager(@QueryParam("userName") String userName , @QueryParam("password") String password)
    {
        //This function accepts login credentials and generates a session key
        AuthenticateUser authenticate = new AuthenticateUser();
        String request_key = authenticate.login(userName, password);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("request_key", request_key);
        return Response.ok().entity(jsonObject.toString()).build();
        
    }
    
    @GET
    @Path("/logout")
    public Response logoutManager(@QueryParam("request_key") String request_key)
    {
        AuthenticateUser authenticate = new AuthenticateUser();
        boolean response= authenticate.logout(request_key);
        if(response)
        {
            return Response.ok().entity("Logged Out "+response).build();
        }
        return Response.ok().entity("Logged Out "+response).build();
    }
    
}
