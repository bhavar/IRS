/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package informationapi.irs;


import APIBrokers.ProductFileResourceBroker;
import APIBrokers.ProductImageResourceBroker;
import APIBrokers.ProductInformationBroker;
import Authenticator.AuthenticateUser;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import javax.activation.MimetypesFileTypeMap;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.IOUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 
 * @author bhawar
 */
@Path("audionsDashboard")
public class AudionsDashboard 
{
    
    @GET
    @Path("/test")
    public Response test()
    {
        return Response.status(Response.Status.OK).entity("Working").build();
    }
    
    @GET
    @Path("/product/images/{product_image_name}")
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response fetchImage(@PathParam("product_image_name") String product_image_name, @QueryParam("request_key") String key)
    {
        try
        {
            AuthenticateUser authenticateUser = new AuthenticateUser();
            if(authenticateUser.isSecureKey(key) && key!=null)
            {
                System.out.println("Requested");
                ProductImageResourceBroker productImageResourceBroker = new ProductImageResourceBroker();
                File img_file = productImageResourceBroker.getImageByFileName(product_image_name);
                if(img_file==null)
                {
                    return Response.ok().entity("Null Object Received").build();
                }
                String mt = new MimetypesFileTypeMap().getContentType("image/jpeg");
                return Response.ok(img_file, mt).build();
            }
            else
            {
                return Response.status(Response.Status.UNAUTHORIZED).build();
            }
        }
        catch(Exception exception)
        {
            return Response.status(Response.Status.NO_CONTENT).build();
        }
        finally
        {
            
        }
    }
    
    @GET
    @Path("/product/resources/{product_resource_id}")
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response fetchResource(@PathParam("product_resource_id") String product_resource_id , @QueryParam("meta_data") String metadata ,@QueryParam("request_key") String key)
    {
        try
        {
            AuthenticateUser authenticateUser = new AuthenticateUser();
            if(authenticateUser.isSecureKey(key) && key!=null)
            {
                
                ProductFileResourceBroker productFileResourceBroker = new ProductFileResourceBroker();
                File res_file = productFileResourceBroker.getFileByFileId(product_resource_id , metadata);

                if(res_file==null)
                {
                    return Response.status(Response.Status.NO_CONTENT).entity("Null Object Received").build();
                }
                
                
                StreamingOutput streaming = new StreamingOutput() 
                {
                    FileInputStream fileInputStream = new FileInputStream(res_file);
                    @Override
                    public void write(OutputStream out) throws IOException, WebApplicationException {
                        
                        int bytes;
                        while ((bytes = fileInputStream.read()) != -1) {
                            out.write(bytes); 
                        }
                        fileInputStream.close();out.close();
                    }
                };
                
                if(res_file.getName().contains("pdf"))
                {
                    return Response.ok(streaming,"application/pdf")
                        .header("Content-Disposition", "inline; filename=\"" + res_file.getName() + "\"" )
                        .build();
                }
                
                //Case for NC File
                else
                {
                    String final_md5 = DigestUtils.md5Hex(IOUtils.toByteArray(new FileInputStream(res_file)));
                    
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("md5",final_md5);
                    
                    System.out.println("MD5 "+final_md5);
                    
                    return Response.ok(streaming,MediaType.APPLICATION_OCTET_STREAM)
                        .header("Content-Disposition", "attachment; filename=\"" + res_file.getName() + "\"" )
                        .header("md5", jsonObject.toJSONString())
                        .build();
                }
                
            }
            
            else
            {
                return Response.status(Response.Status.UNAUTHORIZED).build();
            }
            
        }
        catch(Exception exception)
        {
            return Response.status(Response.Status.NO_CONTENT).build();
        }
        finally
        {
            
        }
    }
    
    @GET
    @Path("/product/names/{product_name}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response fetchProductDetailsByName(@PathParam("product_name") String product_name , @QueryParam("request_key") String key)
    {
        try
        {
            System.out.println("Key is "+key);
            AuthenticateUser authenticateUser = new AuthenticateUser();
            if(authenticateUser.isSecureKey(key) && key!=null)
            {
                //Ask the broker to fetch information on your behalf
                ProductInformationBroker productInformationBroker = new ProductInformationBroker();
                Response response =  productInformationBroker.getProductDetailByName(product_name);
                System.out.println(response.getEntity().toString());
                return response;
            }
            else
            {
                return Response.status(Response.Status.UNAUTHORIZED).build();
            }
        }
        catch(Exception exception)
        {
            return Response.status(Response.Status.NO_CONTENT).build();
        }
        finally
        {
            System.out.println("Executed");
        }
    }
    
    @GET
    @Path("/product/names")
    @Produces(MediaType.APPLICATION_JSON)
    public Response fetchProductNames(@QueryParam("request_key") String key)
    {
        try
        {
            AuthenticateUser authenticateUser = new AuthenticateUser();
            System.out.println("Got "+key);
            if(authenticateUser.isSecureKey(key) && key!=null)
            {
                System.out.println(key);
                ProductInformationBroker informationBroker = new ProductInformationBroker();
                return Response.ok().entity(informationBroker.getAllProductNames().toJSONString()).build();
            }
            else
            {
                return Response.status(Response.Status.UNAUTHORIZED).build();
            }
        }
        catch(Exception exception)
        {
            return Response.status(Response.Status.NO_CONTENT).build();
        }
        finally
        {
            
        }
    }
    
    
}
