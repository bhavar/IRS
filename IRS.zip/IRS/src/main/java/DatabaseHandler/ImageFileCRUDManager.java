/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseHandler;

import KeysAndStatics.DatabaseEntityNames;
import Template.FileMetaData;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.model.GridFSUploadOptions;
import java.io.InputStream;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.json.simple.JSONObject;

/**
 *
 * @author bhawar
 */
public class ImageFileCRUDManager {

    public boolean insertProductImageFile(InputStream inputStream, FileMetaData metaData) {

        DatabaseConnectionManager dbcon = new DatabaseConnectionManager();
        try {

            MongoDatabase mongoDatabase = dbcon.setUpDatabaseConnection(DatabaseEntityNames.getProductDatabaseName());

            GridFSBucket gridFSBucket = GridFSBuckets.create(mongoDatabase, DatabaseEntityNames.getImageBucketName());
            GridFSUploadOptions options = new GridFSUploadOptions()
                    .chunkSizeBytes(1024)
                    .metadata(new Document()
                            .append("product_name", metaData.getPRODUCT_NAME()));
            
            ObjectId fileId = gridFSBucket.uploadFromStream(metaData.getFILE_NAME(), inputStream, options);

            return true;
        } catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            return false;
        } finally {
            dbcon.terminateDatabaseConnection();
        }
    }

    public boolean deleteProductImageFile(JSONObject file_id) {
        DatabaseConnectionManager dbcon = new DatabaseConnectionManager();
        try {
            MongoDatabase mongoDatabase = dbcon.setUpDatabaseConnection(DatabaseEntityNames.getProductDatabaseName());
            GridFSBucket gridFSBucket = GridFSBuckets.create(mongoDatabase, DatabaseEntityNames.getImageBucketName());

            gridFSBucket.delete(new ObjectId(file_id.get("file_id").toString()));
            return true;
        } catch (Exception exception) {
            return false;
        } finally {
            dbcon.terminateDatabaseConnection();
        }
    }
}
