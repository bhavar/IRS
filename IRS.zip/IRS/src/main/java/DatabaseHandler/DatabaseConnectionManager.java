/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseHandler;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoDatabase;

/**
 *
 * @author bhawar
 */
public class DatabaseConnectionManager {

    private String CONNECTION_STRING = "mongodb://bhawar:bhawar96@sugar-shard-00-00-ehsqq.mongodb.net:27017,sugar-shard-00-01-ehsqq.mongodb.net:27017,sugar-shard-00-02-ehsqq.mongodb.net:27017/products?ssl=true&replicaSet=sugar-shard-0&authSource=admin";
    private MongoClient mongoClient;
    
    public MongoDatabase setUpDatabaseConnection(String databaseName) {
        try {
            //Default Code
            //CodecRegistry pojoCodecRegistry = fromRegistries(MongoClient.getDefaultCodecRegistry(),
                    //fromProviders(PojoCodecProvider.builder().automatic(true).build()));
            MongoClientURI mongoClientUri = new MongoClientURI(this.CONNECTION_STRING);

            //Typed Code
            mongoClient = new MongoClient(mongoClientUri);
            MongoDatabase mongoDatabase = mongoClient.getDatabase(databaseName);
            //mongoDatabase.withCodecRegistry(pojoCodecRegistry);
            return mongoDatabase;
        } catch (Exception exception) {
            System.out.println("Error from DBCon"+exception.getMessage());;
        }
        return null;
    }
    
    public void terminateDatabaseConnection()
    {
        mongoClient.close();
    }

}
