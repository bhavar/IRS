/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseHandler;

import KeysAndStatics.DatabaseEntityNames;
import Template.ProductTemplate;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.eq;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author bhawar
 */
public class ProductCRUDManager {

    public boolean deleteProduct(JSONObject request_string) {
        DatabaseConnectionManager dbcon = new DatabaseConnectionManager();

        try 
        {
            //Check if the request_string is valid
            if(!request_string.containsKey("_id"))
            {
                return false;
            }
            MongoDatabase mongoDatabase = dbcon.setUpDatabaseConnection(DatabaseEntityNames.getProductDatabaseName());
            MongoCollection<Document> mongoCollection = mongoDatabase.getCollection(DatabaseEntityNames.getProductCollectionName());
            mongoCollection.deleteOne(eq("_id",new ObjectId(request_string.get("_id").toString())));
            
            return true;
        } 
        catch (Exception exception) 
        {
            exception.getMessage();
            return false;
        } 
        finally 
        {
            dbcon.terminateDatabaseConnection();
        }
    }
    
    public boolean insertProduct(JSONObject json_insert_request)
    {
        DatabaseConnectionManager dbcon = new DatabaseConnectionManager();
        try
        {
            
            JSONObject request_string = json_insert_request;
            MongoDatabase mongoDatabase = dbcon.setUpDatabaseConnection(DatabaseEntityNames.getProductDatabaseName());
            
            //Check if the request_string is valid
            if(!json_insert_request.containsKey("PRODUCT_NAME")||!json_insert_request.containsKey("ALTERNATE_NAME")
                    ||!json_insert_request.containsKey("SIZE") ||!json_insert_request.containsKey("FINISH")
                    ||!json_insert_request.containsKey("HC"))
            {
                return false;
            }
            
            //Set productTemplate and make ready for insert
            
            ProductTemplate productTemplate = new ProductTemplate();
            productTemplate.setNAME(request_string.get("PRODUCT_NAME").toString());
            productTemplate.setALTERNATE_NAME(request_string.get("ALTERNATE_NAME").toString());
            
            productTemplate.setSIZES((JSONArray)request_string.get("SIZE"));
            productTemplate.setFINISH((JSONArray)request_string.get("FINISH"));
            productTemplate.setHC((JSONArray)request_string.get("HC"));
            
            
            Document to_insert = new Document("PRODUCT_NAME",productTemplate.getNAME())
                    .append("ALTERNATE_NAME", productTemplate.getALTERNATE_NAME())
                    .append("SIZE",productTemplate.getSIZES())
                    .append("FINISH",productTemplate.getFINISH())
                    .append("HC",productTemplate.getHC());
            //Insert
            MongoCollection mongoCollection = mongoDatabase.getCollection(DatabaseEntityNames.getProductCollectionName());    
            mongoCollection.insertOne(to_insert);
            
            return true;
        }
        catch(Exception exception)
        {
            System.out.println(exception.getMessage());
            return false;
        }  
        finally
        {
            dbcon.terminateDatabaseConnection();
        }
    }
    
    public boolean updateProduct(JSONObject whole_document)
    {
        try
        {
            System.out.println("Attempting to parse");
            //Check if the request_string is valid
            if(!whole_document.containsKey("PRODUCT_NAME")||!whole_document.containsKey("ALTERNATE_NAME")
                    ||!whole_document.containsKey("SIZE") ||!whole_document.containsKey("FINISH")
                    ||!whole_document.containsKey("HC"))
            {
                System.out.println("Incorrect Arguments");
                return false;
            }
            System.out.println("request is valid");
            if(this.deleteProduct(whole_document))
            {
                this.insertProduct(whole_document);
                return true;
            }
            else
            {
                return false;
            }
        }
        catch(Exception exception)
        {
            System.out.println(exception.getMessage());
            return false;
        }
        finally
        {
            
        }
    }    
}
