/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseHandler;

import KeysAndStatics.DatabaseEntityNames;
import Template.FileMetaData;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.model.GridFSUploadOptions;
import static com.mongodb.client.model.Filters.eq;
import com.mongodb.client.result.UpdateResult;
import java.io.InputStream;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.json.simple.JSONObject;

/**
 *
 * @author bhawar
 */
public class ResourceFileCRUDManager {

    public boolean insertProductResourceFile(InputStream inputStream, FileMetaData metaData) {

        DatabaseConnectionManager dbcon = new DatabaseConnectionManager();
        try {
            
            Thread thread = new Thread(){
                MongoDatabase mongoDatabase = dbcon.setUpDatabaseConnection(DatabaseEntityNames.getProductDatabaseName());

                GridFSBucket gridFSBucket = GridFSBuckets.create(mongoDatabase, DatabaseEntityNames.getResourceBucketName());
                GridFSUploadOptions options = new GridFSUploadOptions()
                        .chunkSizeBytes(1024)
                        .metadata(new Document()
                                .append("version_name", metaData.getVERSION_NAME())
                                .append("product_name", metaData.getPRODUCT_NAME())
                                .append("product_size",metaData.getProductSize()));

                ObjectId fileId = gridFSBucket.uploadFromStream(metaData.getFILE_NAME(), inputStream, options);
            };
            thread.start();
            return true;
        } catch (Exception exception)
        {
            System.out.println(exception.getMessage());
            return false;
        } finally {
            dbcon.terminateDatabaseConnection();
        }
    }

    public boolean deleteProductResourceFile(JSONObject file_id) {
        DatabaseConnectionManager dbcon = new DatabaseConnectionManager();
        try {
            MongoDatabase mongoDatabase = dbcon.setUpDatabaseConnection(DatabaseEntityNames.getProductDatabaseName());
            GridFSBucket gridFSBucket = GridFSBuckets.create(mongoDatabase, DatabaseEntityNames.getResourceBucketName());

            gridFSBucket.delete(new ObjectId(file_id.get("file_id").toString()));
            return true;
        } catch (Exception exception) {
            return false;
        } finally {
            dbcon.terminateDatabaseConnection();
        }
    }
    
    public boolean updateProductInformation(JSONObject metaData)
    {
        //receive file_id , product_name, version_name ,product_size,new_fileName
        DatabaseConnectionManager dbcon = new DatabaseConnectionManager();
        try
        {
            System.out.println("Attempting to Update product_information");
            MongoDatabase mongoDatabase = dbcon.setUpDatabaseConnection(DatabaseEntityNames.getProductDatabaseName());
            GridFSBucket gridFSBucket = GridFSBuckets.create(mongoDatabase, DatabaseEntityNames.getResourceBucketName());
            
            //rename file
            //gridFSBucket.rename(new ObjectId(metaData.get("file_id").toString()), metaData.get("new_fileName").toString());
            
            String file_id = metaData.get("file_id").toString();
            
            MongoCollection mongoCollection = mongoDatabase.getCollection(DatabaseEntityNames.getResourceBucketName()+".files");
            UpdateResult updateResult = mongoCollection.updateOne(eq("_id",new ObjectId(file_id)),
                    new Document("$set",new Document("metadata",
                            new Document()
                            .append("version_name",metaData.get("version_name").toString())
                            .append("product_name", metaData.get("product_name").toString())
                            .append("product_size", metaData.get("product_size").toString())
                    )));
            System.out.println("Status Unknown before return "+updateResult.getUpsertedId()+" "+updateResult.getMatchedCount());
            return updateResult.wasAcknowledged();
        }
        catch(Exception exception)
        {
            System.out.println(exception.getMessage());
            return false;
        }
        finally
        {
            dbcon.terminateDatabaseConnection();
        }
    }
    
}
