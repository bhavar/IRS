/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Template;

import java.util.ArrayList;
import javax.xml.bind.annotation.XmlRootElement;
import org.json.simple.JSONArray;

/**
 *
 * @author bhawar
 */
public class ProductTemplate
{
    
        
    String NAME,ALTERNATE_NAME;
    JSONArray SIZES,HC,FINISH;

    public String getNAME() {
        return NAME;
    }

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

    public String getALTERNATE_NAME() {
        return ALTERNATE_NAME;
    }

    public void setALTERNATE_NAME(String ALTERNATE_NAME) {
        this.ALTERNATE_NAME = ALTERNATE_NAME;
    }

    public ArrayList getSIZES() {
        return SIZES;
    }

    public void setSIZES(JSONArray SIZES) {
        this.SIZES = SIZES;
    }

    public ArrayList getHC() {
        return HC;
    }

    public void setHC(JSONArray HC) {
        this.HC = HC;
    }

    public ArrayList getFINISH() {
        return FINISH;
    }

    public void setFINISH(JSONArray FINISH) {
        this.FINISH = FINISH;
    }
    
}
