/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Template;

/**
 *
 * @author bhawar
 */
public class FileMetaData
{
    
    private String PRODUCT_NAME,FILE_NAME,TYPE,VERSION_NAME,PRODUCT_SIZE;

    /**
     * @return the PRODUCT_NAME
     */
    public String getPRODUCT_NAME() {
        return PRODUCT_NAME;
    }

    /**
     * @param PRODUCT_NAME the PRODUCT_NAME to set
     */
    public void setPRODUCT_NAME(String PRODUCT_NAME) {
        this.PRODUCT_NAME = PRODUCT_NAME;
    }

    /**
     * @return the FILE_NAME
     */
    public String getFILE_NAME() {
        return FILE_NAME;
    }

    /**
     * @param FILE_NAME the FILE_NAME to set
     */
    public void setFILE_NAME(String FILE_NAME) {
        this.FILE_NAME = FILE_NAME;
    }

    /**
     * @return the TYPE
     */
    public String getTYPE() {
        return TYPE;
    }

    /**
     * @param TYPE the TYPE to set
     */
    public void setTYPE(String TYPE) {
        this.TYPE = TYPE;
    }

    /**
     * @return the VERSION_NAME
     */
    public String getVERSION_NAME() {
        return VERSION_NAME;
    }

    /**
     * @param VERSION_NAME the VERSION_NAME to set
     */
    public void setVERSION_NAME(String VERSION_NAME) {
        this.VERSION_NAME = VERSION_NAME;
    }
    
    public void setProductSize(String PRODUCT_SIZE)
    {
        this.PRODUCT_SIZE = PRODUCT_SIZE;
    }
    
    public String getProductSize()
    {
        return PRODUCT_SIZE;
    }
    
    
}
