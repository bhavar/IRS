/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CustomTestSuite;

import DatabaseHandler.DatabaseConnectionManager;
import KeysAndStatics.DatabaseEntityNames;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.model.GridFSUploadOptions;
import static com.mongodb.client.model.Filters.eq;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author bhawar
 */
public class NewEmptyJUnitTest {
    
    public NewEmptyJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    
    public void executeTest()
    {
        DatabaseConnectionManager dbcon = new DatabaseConnectionManager();
        try 
        {
            File file = new File("/tmp/demo.pdf");
            
            InputStream inputStream = new FileInputStream(file);
            
            //MongoClientURI mongoClientUri = new MongoClientURI("");

            //Typed Code
            MongoClient mongoClient = new MongoClient();
            MongoDatabase mongoDatabase = mongoClient.getDatabase("custom");

            GridFSBucket gridFSBucket = GridFSBuckets.create(mongoDatabase, DatabaseEntityNames.getResourceBucketName());
            GridFSUploadOptions options = new GridFSUploadOptions()
                    .chunkSizeBytes(1024);
            
            ObjectId fileId = gridFSBucket.uploadFromStream("demo", inputStream, options);
            System.out.println("Uploaded");
        }
        catch(Exception exception)
        {
            System.out.println(exception.getMessage());
        }
    }
    
    @Test
    public void executeTest2()
    {
        ThreadEngine threadEngine = new ThreadEngine();
       
    }
    
    public class ThreadEngine implements Runnable
    {
        
        public ThreadEngine()
        {
            Thread thread = new Thread(this);
            thread.start();
        }

        @Override
        public void run() {
            System.out.println("Thread Running");
        }
        
    }
    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
